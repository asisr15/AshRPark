import static org.junit.Assert.*;
import org.junit.Test;
import parkingLot.AutomatedParkingLot;
import parkingLot.ParkingLot;
import parkingLot.ParkingSlot;
import parkingLot.Size;
import vehicle.SmallCar;
import vehicle.Vehicle;

public class testParking {

  @Test
  public void canParkSmallCarInSmallParkingSlot() {
    ParkingLot automatedParkingLot = new AutomatedParkingLot();
    automatedParkingLot.initialiseParkingLot(2, 2, 2);
    Vehicle smallCar = new SmallCar();
    if (automatedParkingLot.checkAvailability(Size.SMALL)) {
      ParkingSlot ps = automatedParkingLot.allocateParkingSlot(smallCar);
      String token = ps.park(smallCar);
      assertNotNull(token);
    }
//    fail("Not yet implemented");
  }
  
  @Test
  public void canParkMediumCarInMediumParkingSlot() {
    fail("Not yet implemented");
  }

}
