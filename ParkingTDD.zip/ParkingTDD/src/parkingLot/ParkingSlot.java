package parkingLot;

import vehicle.Vehicle;

public interface ParkingSlot {
  
  
//  void setSlotSize(Size parkingSlotSize);
//  void setPriceperHour(int rupees);
  boolean isAvailable();
  String park(Vehicle car);
  Size getSlotSize();
  int getPricePerHour();
  

}
