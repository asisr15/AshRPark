package parkingLot;

import java.util.UUID;
import vehicle.Vehicle;

public class SmallParkingSlot implements ParkingSlot {
  
  boolean available;

  @Override
  public Size getSlotSize() {
    // TODO Auto-generated method stub
    return Size.SMALL;

  }

  @Override
  public int getPricePerHour() {
    // TODO Auto-generated method stub
    return 10;

  }

  @Override
  public boolean isAvailable() {
    // TODO Auto-generated method stub
    return available;
  }

  @Override
  public String park(Vehicle car) {
    // TODO Auto-generated method stub
    available= false;
    return UUID.randomUUID().toString();

  }

}
