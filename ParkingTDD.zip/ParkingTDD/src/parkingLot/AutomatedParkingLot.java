package parkingLot;

import java.util.LinkedList;
import java.util.List;
import vehicle.Vehicle;

public class AutomatedParkingLot implements ParkingLot {

  List<ParkingSlot> availableSmallParkingSlot = new LinkedList<ParkingSlot>();
  List<ParkingSlot> occupiedSmallParkingSlot = new LinkedList<ParkingSlot>();

  @Override
  public void initialiseParkingLot(int small, int medium, int large) {
    // TODO Auto-generated method stub
//    availableSmallParkingSlot = new 
    
    for (int s = 0; s < small; s++) {
      availableSmallParkingSlot.add(new SmallParkingSlot());

    }
  }

  @Override
  public boolean checkAvailability(Size vehicleSize) {
    // TODO Auto-generated method stub
    switch (vehicleSize) {
      case SMALL:
        if (!availableSmallParkingSlot.isEmpty()) {
          return true;
        }
        // case MEDIUM:
      default:
        return false;
    }

  }

  @Override
  public ParkingSlot allocateParkingSlot(Vehicle v) {
    ParkingSlot slot = availableSmallParkingSlot.get(0);
    occupiedSmallParkingSlot.add(slot);
    return slot;
    // TODO Auto-generated method stub

  }



}
