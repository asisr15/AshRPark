package parkingLot;

import java.util.List;
import vehicle.Vehicle;

public interface ParkingLot {
//  List<ParkingSlots> parkingSlots;
  boolean checkAvailability(Size vehicleSize);
  ParkingSlot allocateParkingSlot(Vehicle v);
  void initialiseParkingLot(int small, int medium, int large);
  

}
