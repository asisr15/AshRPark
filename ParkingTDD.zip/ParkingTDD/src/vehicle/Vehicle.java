package vehicle;

import parkingLot.Size;

public interface Vehicle {
  void setSize(Size vehicleSize);
  void setID(String vehicleID);
  

}
