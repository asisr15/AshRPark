package vehicle;

import parkingLot.Size;

public class SmallCar implements Vehicle {

  @Override
  public void setSize(Size vehicleSize) {
    // TODO Auto-generated method stub

  }

  @Override
  public void setID(String vehicleID) {
    // TODO Auto-generated method stub

  }

}
