import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ParkingMain {
	Scanner sc = new Scanner(System.in);

	static int parkingslots = 15;
	static int small;
	static int medium;
	static int large;
	int ticket;
	long startTime, endTime, time;
	double cost;
	String id;

	static List<Vehicle> slots = new ArrayList<Vehicle>();

	public static void main(String[] args) {
		System.out.println("*****PARKING LOTTO*****");

		ParkingMain parkmain = new ParkingMain();

		parkmain.menu();

	}

	public void menu() {
		int option;
		ParkingMain parkmain2 = new ParkingMain();

		System.out.println("Insert Details:-\n");
		System.out.println("1.Add Vehicle details \n");
		System.out.println("2.Remove your vehicle from parking \n");
		System.out.println("3.Exit\n");
		System.out.println(".....");
		option = sc.nextInt();

		switch (option) {
		case 1:
			parkmain2.addVehicle();
			break;
		case 2:
			parkmain2.deleteVehicle();
			break;
		case 3:
			System.exit(0);
			break;
		default:
			System.out.println("Invalid input!");
			menu();
		}
	}

	public void addVehicle() {
		Scanner sc = new Scanner(System.in);
		int vehicletype;

		ParkingMain parkmain2 = new ParkingMain();

		System.out.println("\n Welcome to LOTTO PARKING....add your vehicle details:-!\n");

		freeslots();

		if (parkingslots > 0) {
			System.out.println("Select your vehicle type:-\n");
			System.out.println("1.SMALL\t\t Rate:- Rs10/hr\n");
			System.out.println("2.MEDIUM\t Rate:- Rs15/hr\n");
			System.out.println("3.LARGE\t\t Rate:- Rs20/hr\n");

			vehicletype = sc.nextInt();

			switch (vehicletype) {
			case 1:
				Vehicle vehicle = new Vehicle();

				System.out.println("\n*****LOTTO PARKING TICKET*****\n");
				vehicle.setEntryTime(System.currentTimeMillis());
				vehicle.setVehicletype("Small");
				System.out.println("Enter the Vehicle ID:-\n");
				vehicle.setVname(sc.next());

				slots.add(vehicle);

				ticket = getToken();

				System.out.println("\nTicket Number:- " + ticket);

				startTime = System.currentTimeMillis();

				parkingslots--;

				small++;

				if (small > 5 && parkingslots >= 1) {
					System.out.println("\nNo more space available for your vehicle to park.\n");
					System.out.println("Wanna add to other available slot paying higher price?\t1.Yes 2.No");
					switch (sc.nextInt()) {
					case 1:
						parkmain2.addVehicle();
						break;
					case 2:
						System.exit(0);
						break;
					default:
						System.out.println("Invalid input");
						break;
					}
					// returnToMenu();
				} else {

					returnToMenu();
				}
				break;

			case 2:

				Vehicle vehicle1 = new Vehicle();

				System.out.println("\n*****LOTTO PARKING TICKET*****\n");
				vehicle1.setEntryTime(System.currentTimeMillis());
				vehicle1.setVehicletype("Medium");
				System.out.println("Enter the Vehicle ID:-\n");
				vehicle1.setVname(sc.next());

				slots.add(vehicle1);

				ticket = getToken();

				System.out.println("\nTicket Number:- " + ticket);

				parkingslots--;

				medium++;

				if (medium > 5 && parkingslots >= 1) {
					System.out.println("\nNo more space available for your vehicle to park.\n");
					System.out.println("Wanna add to other available slot paying higher price?\t1.Yes 2.No");
					switch (sc.nextInt()) {
					case 1:
						parkmain2.addVehicle();
						break;
					case 2:
						System.exit(0);
						break;
					default:
						System.out.println("Invalid input");
						break;
					}
				} else {

					returnToMenu();
				}

				break;

			case 3:
				if (parkingslots > 2) {
					Vehicle vehicle2 = new Vehicle();

					System.out.println("\n*****LOTTO PARKING TICKET*****\n");
					vehicle2.setEntryTime(System.currentTimeMillis());
					vehicle2.setVehicletype("Large");
					System.out.println("Enter the Vehicle ID:-\n");
					vehicle2.setVname(sc.next());

					slots.add(vehicle2);

					ticket = getToken();
					System.out.println("\nTicket Number:- " + ticket);

					parkingslots--;

					large++;
					if (large > 5) {
						System.out.println("No more space available for your vehicle to park.");
						returnToMenu();
					} else {

						returnToMenu();
					}
				} else {
					System.out.println("No space available right now!");
				}
				returnToMenu();

				break;

			default:
				System.out.println("\nInvalid Input! Try again plz!");
				addVehicle();
				break;
			}
		}
	}

	private int getToken() {
		return (int) ((Math.random() * 9000) + 1000);
	}

	public void deleteVehicle() {
		long totalVehicles = (small + medium + large);

		if (totalVehicles == 0) {
			System.out.println("No vehicle in the parking lot. Please add vehicle.");
		} else {
			System.out.println("\nVehicle is parked:-\n Enter your ID to un-park:-\n");
			for (Vehicle vehicle : slots) {
				id = vehicle.getVname();
				if (id != null)
					System.out.println("\t" + id);
			}
			System.out.println("\nSelect your vehicle:-\n");

			String deleteVehicle = sc.next();
			String leavingVehicle = slots.get(getIndexByProperty(deleteVehicle)).getVehicletype();
			long entryTime = slots.get(getIndexByProperty(deleteVehicle)).getEntryTime();
			System.out.println("\nA " + leavingVehicle + " is leaving the parking lot....THANKS!!!");

			time = ((System.currentTimeMillis() - entryTime) / 1000); // / (1000
																		// *
																		// 60);

			System.out.println("Vehicle ID " + id + " Your...");
			System.out.println("\nElapsed Time is:  " + time + "secs");

			if (leavingVehicle.equals("Medium")) {
				parkingslots++;
				medium--;

				System.out.println("Your total cost is Rs. " + calculateCost(time, leavingVehicle));
			} else if (leavingVehicle.equals("Large")) {
				parkingslots++;
				large--;
				System.out.println("Your total cost is Rs. " + calculateCost(time, leavingVehicle));

			} else if (leavingVehicle.equals("Small")) {
				parkingslots++;
				small--;
				System.out.println("Your total cost is Rs. " + calculateCost(time, leavingVehicle));
			}
			System.out.println("\n*****THANK YOU VISIT AGAIN!!!******");

			slots.remove(getIndexByProperty(deleteVehicle));
		}
		returnToMenu();
	}

	private double calculateCost(Long time, String size) {
		if (size.equalsIgnoreCase("Large")) {
			return ((time * 20) / 3600);
		} else if (size.equalsIgnoreCase("Medium")) {
			return ((time * 15) / 3600);
		} else {
			return ((time * 10) / 3600);
		}
	}

	private int getIndexByProperty(String yourString) {
		for (int i = 0; i < slots.size(); i++) {
			if (slots.get(i).getVname() != null && slots.get(i).getVname().equalsIgnoreCase(yourString)) {
				return i;
			}
		}
		System.out.println("\nSorry! There's no vehicle in the park with the specified ID plate.\n");
		return -1;
	}

	public void freeslots() {
		if (parkingslots > 0) {
			if (parkingslots == 1) {
				System.out.println("Maybe one slot remaining.\n");
			} else {
				System.out.println("\n There are " + parkingslots + " parking slots remaining!\n");
			}
		} else {
			System.out.println("No slots for parking...sorry :/ \n");
		}
	}

	public void returnToMenu() {
		try {
			System.out.println("\nDo you want to continue with the slot booking?\n");
			System.out.println(" Please select your option \n 1. Yes \n 2. No");

			switch (sc.nextInt()) {
			case 1:
				menu();
				break;
			case 2:
				System.exit(0);
				break;
			default:
				System.out.println("\nInvalid option!");
				menu();
				break;
			}
		} catch (Exception e) {
			System.out.println("\nInvalid option!");
			menu();
		}
	}
}